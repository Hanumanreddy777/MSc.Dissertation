// apiConfig.js
const apiUrl = 'http://192.168.100.127:3304';

export default apiUrl;