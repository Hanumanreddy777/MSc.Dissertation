// DetailScreen.js
import React from 'react';
import { View, Text } from 'react-native';

const DetailScreen = ({ navigation }) => (
  <View>
    <Text>Detail Screen</Text>
    {/* Add the content of your detail screen here */}
  </View>
);

export default DetailScreen;
